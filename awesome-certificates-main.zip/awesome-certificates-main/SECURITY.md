# Security Policy

## Reporting a Vulnerability

Incase you find any security vulnerabilities, [fork](https://github.com/PanXProject/awesome-certificates/fork) this repo to [open an issue](https://github.com/PanXProject/awesome-certificates/compare) or [start a disccusion](https://discord.com/invite/3kSS9dvnPz) and we'll investigate it.
